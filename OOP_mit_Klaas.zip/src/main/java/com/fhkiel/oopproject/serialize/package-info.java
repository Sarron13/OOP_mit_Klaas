/**
 * contains Serializer implementation
 */
package com.fhkiel.oopproject.serialize;