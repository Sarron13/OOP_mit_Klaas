/**
 * contains all data model for the characters
 */
package com.fhkiel.oopproject.model;