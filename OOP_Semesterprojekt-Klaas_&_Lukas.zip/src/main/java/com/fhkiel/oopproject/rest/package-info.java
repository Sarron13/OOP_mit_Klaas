/**
 * contains all Spring REST Components
 */
package com.fhkiel.oopproject.rest;