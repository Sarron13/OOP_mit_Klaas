/**
 * contains container implementation
 */
package com.fhkiel.oopproject.container;